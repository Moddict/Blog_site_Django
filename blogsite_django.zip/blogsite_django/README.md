# Django-blog-app
This is the blog app with Django Python
Use /admin after generated url to connect to webapp
below is shown how to use it:
http://127.0.0.1:8000/admin
